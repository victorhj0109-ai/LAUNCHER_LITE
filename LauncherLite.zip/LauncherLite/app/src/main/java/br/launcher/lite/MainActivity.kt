package br.launcher.lite

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.provider.Settings
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.Executors

private class G(val ts: Long, val title: String, val league: String, val chan: String)

class MainActivity : Activity() {
    private val TMDB = "COLOQUE_SUA_CHAVE_TMDB"
    private val ROXO = 0xFFA855F7.toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val net = Executors.newFixedThreadPool(5)
    private val imgIo = Executors.newFixedThreadPool(2)
    private var movieArr: org.json.JSONArray? = null
    private var seriesArr: org.json.JSONArray? = null
    private lateinit var appsRow: LinearLayout
    private lateinit var gamesRow: LinearLayout
    private lateinit var moviesRow: LinearLayout
    private lateinit var seriesRow: LinearLayout
    private lateinit var heroImg: ImageView
    private lateinit var heroTitle: TextView
    private lateinit var heroInfo: TextView
    private lateinit var heroDesc: TextView
    private val heroItems = ArrayList<JSONObject>()
    private var heroIdx = 0
    private var lastLoad = 0L
    private var firstFocus = true
    private lateinit var netIcon: ImageView
    private var cm: ConnectivityManager? = null
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) { ui.postDelayed({ updateNet() }, 400) }
        override fun onLost(n: Network) { ui.postDelayed({ updateNet() }, 400) }
        override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) { ui.postDelayed({ updateNet() }, 400) }
    }

    @Suppress("DEPRECATION")
    private fun updateNet() {
        val i = cm?.activeNetworkInfo
        val t = if (i != null && i.isConnected) i.type else -1
        when (t) {
            ConnectivityManager.TYPE_WIFI -> { netIcon.setImageResource(R.drawable.ic_wifi); netIcon.visibility = View.VISIBLE }
            ConnectivityManager.TYPE_ETHERNET -> { netIcon.setImageResource(R.drawable.ic_eth); netIcon.visibility = View.VISIBLE }
            else -> netIcon.visibility = View.GONE
        }
    }
    private val rotate = object : Runnable {
        override fun run() {
            if (heroItems.size > 1) { heroIdx = (heroIdx + 1) % heroItems.size; showHero() }
            ui.postDelayed(this, 8000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF000000.toInt(), 0xFF2A0A4D.toInt())))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(24), dp(32), dp(32))
            clipChildren = false; clipToPadding = false
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; clipChildren = false; setPadding(0, dp(6), 0, dp(6)) }
        head.addView(TextView(this).apply {
            text = "JV Launcher"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        netIcon = ImageView(this).apply {
            visibility = View.GONE; setPadding(dp(7), dp(7), dp(7), dp(7))
            background = roundBg(Color.TRANSPARENT, dp(10).toFloat())
        }
        focusScale(netIcon, netIcon.background as GradientDrawable, 1.15f)
        netIcon.setOnClickListener { openSettings(Settings.ACTION_WIFI_SETTINGS) }
        head.addView(netIcon, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        head.addView(TextClock(this).apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 20f; setTextColor(Color.WHITE) })
        val gear = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_preferences); setColorFilter(Color.WHITE)
            setPadding(dp(7), dp(7), dp(7), dp(7)); background = roundBg(Color.TRANSPARENT, dp(10).toFloat())
        }
        focusScale(gear, gear.background as GradientDrawable, 1.15f)
        gear.setOnClickListener { showGearMenu() }
        head.addView(gear, LinearLayout.LayoutParams(dp(36), dp(36)).apply { leftMargin = dp(14) })
        root.addView(head)
        buildHero(root)
        appsRow = section(root, "Seus apps")
        gamesRow = section(root, "Próximos jogos")
        moviesRow = section(root, "Top 10 filmes da semana")
        seriesRow = section(root, "Top 10 séries da semana")
        setContentView(ScrollView(this).apply { clipChildren = false; clipToPadding = false; addView(root) })
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    private fun showGearMenu() {
        AlertDialog.Builder(this).setTitle("Opções")
            .setItems(arrayOf("Opções da Launcher", "Opções do Android")) { _, w ->
                if (w == 0) launcherOptions() else openSettings(Settings.ACTION_SETTINGS)
            }.show()
    }

    private fun launcherOptions() {
        val sp = getSharedPreferences("l", 0)
        val estilo = if (iconStyle(this) == "rect") "Retangulares" else "Redondos"
        val auto = sp.getString("auto", "") ?: ""
        val nome = if (auto.isEmpty()) "Nenhum" else try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(auto, 0)).toString()
        } catch (e: Exception) { "Nenhum" }
        AlertDialog.Builder(this).setTitle("Opções da Launcher")
            .setItems(arrayOf("Ícones: $estilo", "Abrir app ao ligar a TV: $nome")) { _, w ->
                if (w == 0) pickStyle() else pickAuto()
            }.show()
    }

    private fun pickStyle() {
        val sp = getSharedPreferences("l", 0)
        val cur = if (iconStyle(this) == "rect") 1 else 0
        AlertDialog.Builder(this).setTitle("Estilo dos ícones")
            .setSingleChoiceItems(arrayOf("Redondos", "Retangulares"), cur) { d, w ->
                sp.edit().putString("style", if (w == 1) "rect" else "round").apply()
                d.dismiss(); refreshApps()
            }.show()
    }

    private fun pickAuto() {
        val sp = getSharedPreferences("l", 0)
        val apps = launchableApps(this)
        val pm = packageManager
        val names = arrayOf("Nenhum") + apps.map { it.loadLabel(pm).toString() }
        AlertDialog.Builder(this).setTitle("Abrir ao ligar a TV (só 1 vez por ligada)")
            .setItems(names) { _, w ->
                val pkg = if (w == 0) "" else apps[w - 1].activityInfo.packageName
                sp.edit().putString("auto", pkg).putLong("lastElapsed", SystemClock.elapsedRealtime()).apply()
            }.show()
    }

    private fun checkAutoStart() {
        val sp = getSharedPreferences("l", 0)
        val now = SystemClock.elapsedRealtime()
        val auto = sp.getString("auto", "") ?: ""
        val rebooted = now < sp.getLong("lastElapsed", 0L)
        sp.edit().putLong("lastElapsed", now).apply()
        if (auto.isNotEmpty() && rebooted) ui.postDelayed({ launchPkg(this, auto) }, 1200)
    }

    override fun onResume() {
        super.onResume()
        checkAutoStart()
        refreshApps()
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try { cm?.registerNetworkCallback(NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb) } catch (e: Exception) { }
        updateNet()
        ui.removeCallbacks(rotate); ui.postDelayed(rotate, 8000)
        if (System.currentTimeMillis() - lastLoad > 30 * 60_000L) {
            lastLoad = System.currentTimeMillis()
            loadGames(); loadMedia("movie", moviesRow); loadMedia("tv", seriesRow)
        }
    }

    override fun onPause() {
        super.onPause(); ui.removeCallbacks(rotate)
        try { cm?.unregisterNetworkCallback(netCb) } catch (e: Exception) { }
    }

    private fun buildHero(root: LinearLayout) {
        val hero = FrameLayout(this).apply {
            background = roundBg(0xFF1E1233.toInt(), dp(20).toFloat())
            clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        heroImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1))
        hero.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF000000.toInt(), 0xCC000000.toInt(), 0x00000000))
        }, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM; setPadding(dp(20), dp(16), dp(16), dp(16))
        }
        col.addView(TextView(this).apply { text = "EM ALTA"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ROXO) })
        heroTitle = TextView(this).apply { text = "JV Launcher"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); maxLines = 2 }
        heroInfo = TextView(this).apply { textSize = 13f; setTextColor(0xFFD8C4FF.toInt()); setPadding(0, dp(4), 0, dp(4)) }
        heroDesc = TextView(this).apply { textSize = 13f; setTextColor(0xDDFFFFFF.toInt()); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(heroTitle); col.addView(heroInfo); col.addView(heroDesc)
        hero.addView(col, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.6).toInt(), -1))
        hero.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = ((r - l) * 0.6).toInt()
            if (w > 0 && col.layoutParams.width != w) { col.layoutParams.width = w; col.post { col.requestLayout() } }
        }
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(12) })
    }

    private fun showHero() {
        val o = heroItems[heroIdx]
        heroTitle.text = s(o, "title").ifEmpty { s(o, "name") }
        val ano = s(o, "release_date").ifEmpty { s(o, "first_air_date") }.take(4)
        val tipo = if (s(o, "media_type") == "tv") "Série" else "Filme"
        heroInfo.text = "★ " + String.format(Locale.US, "%.1f", o.optDouble("vote_average")) + " · $ano · $tipo"
        heroDesc.text = s(o, "overview")
        Img.load(imgIo, heroImg, "https://image.tmdb.org/t/p/w780" + s(o, "backdrop_path"))
    }

    private fun rebuildHero() {
        heroItems.clear()
        fun take(a: org.json.JSONArray?, n: Int, type: String) {
            if (a == null) return
            var c = 0
            for (i in 0 until a.length()) {
                if (c >= n) break
                val o = a.getJSONObject(i)
                if (s(o, "backdrop_path").isNotEmpty()) { o.put("media_type", type); heroItems.add(o); c++ }
            }
        }
        take(movieArr, 3, "movie"); take(seriesArr, 2, "tv")
        if (heroItems.isNotEmpty()) { heroIdx = 0; showHero() }
        else heroDesc.text = "Configure a chave do TMDB para ver os destaques"
    }

    private fun section(root: LinearLayout, title: String): LinearLayout {
        root.addView(TextView(this).apply {
            text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFC4A4FF.toInt()); setPadding(0, dp(12), 0, 0)
        })
        val row = LinearLayout(this).apply { clipChildren = false }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; clipToPadding = false; clipChildren = false
            setPadding(dp(16), dp(14), dp(16), dp(14)); addView(row)
        }, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = -dp(16); rightMargin = -dp(16) })
        return row
    }

    private fun msg(t: String) = TextView(this).apply { text = t; setTextColor(0xAAFFFFFF.toInt()); textSize = 14f }

    private fun refreshApps() {
        appsRow.removeAllViews()
        appsRow.addView(bubble(this, "Explorar", null, "▦", 0xFF7C3AED.toInt(),
            { startActivity(Intent(this, AllAppsActivity::class.java)) }))
        val pm = packageManager
        for (p in favs(this)) try {
            val ic = pm.getApplicationIcon(p)
            val lb = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            appsRow.addView(bubble(this, lb, ic, null, 0xFF2B1750.toInt(), { launchPkg(this, p) },
                { saveFavs(this, favs(this) - p); refreshApps() }, bannerFor(pm, p)))
        } catch (e: Exception) { }
        appsRow.addView(bubble(this, "Adicionar", null, "+", 0x33FFFFFF,
            { startActivity(Intent(this, AllAppsActivity::class.java).putExtra("pick", true)) }))
        if (firstFocus) { firstFocus = false; appsRow.getChildAt(0)?.requestFocus() }
    }

    private var sk: String? = null
    private fun sp(path: String): String? {
        val k = sk
        if (k != null) return httpGet("https://www.thesportsdb.com/api/v1/json/$k/$path")
        for (c in arrayOf("123", "3")) {
            val r = httpGet("https://www.thesportsdb.com/api/v1/json/$c/$path")
            if (r != null) { sk = c; return r }
        }
        return null
    }

    private fun s(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k)

    private fun guess(lg: String) = when {
        lg.contains("Brazil", true) || lg.contains("Brasil", true) -> "Provável: Globo / SporTV / Premiere"
        lg.contains("Libertadores") -> "Provável: Globo / ESPN / Disney+"
        lg.contains("Sudamericana") -> "Provável: ESPN / Disney+"
        else -> "Consulte a programação"
    }

    private fun readGames(sp: android.content.SharedPreferences): List<G> = try {
        val arr = org.json.JSONArray(sp.getString("games", "[]"))
        val lim = System.currentTimeMillis() - 2 * 3600_000L
        (0 until arr.length()).map { arr.getJSONObject(it) }
            .map { G(it.getLong("ts"), it.getString("t"), it.getString("l"), it.getString("c")) }
            .filter { it.ts >= lim }
    } catch (e: Exception) { emptyList() }

    private fun saveGames(sp: android.content.SharedPreferences, l: List<G>) {
        val arr = org.json.JSONArray()
        for (g in l) arr.put(JSONObject().put("ts", g.ts).put("t", g.title).put("l", g.league).put("c", g.chan))
        sp.edit().putString("games", arr.toString()).putLong("gt", System.currentTimeMillis()).apply()
    }

    private fun loadGames() {
        val sp0 = getSharedPreferences("l", 0)
        val cached = readGames(sp0)
        if (cached.isNotEmpty()) renderGames(cached, true)
        if (cached.isNotEmpty() && System.currentTimeMillis() - sp0.getLong("gt", 0) < 30 * 60_000L) return
        net.execute {
            val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            val leagues = arrayOf("4351", "4501", "4724")
            val first = sp("eventsnextleague.php?id=${leagues[0]}")
            val tasks = ArrayList<Callable<Pair<String, String?>>>()
            for (l in leagues.drop(1)) tasks.add(Callable { Pair("L", sp("eventsnextleague.php?id=$l")) })
            val cal = Calendar.getInstance(); val dfDay = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            for (k in 0..3) {
                val d = dfDay.format(cal.time); cal.add(Calendar.DAY_OF_MONTH, 1)
                tasks.add(Callable { Pair("T", sp("eventstv.php?d=$d&s=Soccer")) })
            }
            val res = try { net.invokeAll(tasks).map { try { it.get() } catch (e: Exception) { Pair("X", null) } } } catch (e: Exception) { emptyList() }
            val leagueTxt = ArrayList<String>(); val tvTxt = ArrayList<String>()
            if (first != null) leagueTxt.add(first)
            for (r in res) { val t = r.second ?: continue; if (r.first == "L") leagueTxt.add(t) else if (r.first == "T") tvTxt.add(t) }
            val online = leagueTxt.isNotEmpty() || tvTxt.isNotEmpty()
            val ch = HashMap<String, LinkedHashSet<String>>()
            for (t in tvTxt) try {
                val tv = JSONObject(t).optJSONArray("tvevents") ?: continue
                for (i in 0 until tv.length()) {
                    val o = tv.getJSONObject(i)
                    if (s(o, "strCountry") == "Brazil") ch.getOrPut(s(o, "idEvent")) { LinkedHashSet() }.add(s(o, "strChannel"))
                }
            } catch (e: Exception) { }
            val now = System.currentTimeMillis()
            val list = ArrayList<G>()
            for (t in leagueTxt) try {
                val ev = JSONObject(t).optJSONArray("events") ?: continue
                for (i in 0 until ev.length()) {
                    val o = ev.getJSONObject(i)
                    val ts = try { fmtIn.parse(s(o, "strTimestamp"))?.time ?: 0L } catch (e: Exception) { 0L }
                    if (ts == 0L || ts < now - 2 * 3600_000L) continue
                    val lg = s(o, "strLeague")
                    val c = ch[s(o, "idEvent")]?.joinToString(" / ") ?: guess(lg)
                    list.add(G(ts, s(o, "strHomeTeam") + " x " + s(o, "strAwayTeam"), lg, c))
                }
            } catch (e: Exception) { }
            list.sortBy { it.ts }
            val top = list.take(12)
            if (top.isNotEmpty()) {
                saveGames(sp0, top)
                runOnUiThread { renderGames(top, true) }
            } else if (cached.isEmpty()) runOnUiThread { renderGames(emptyList(), online) }
        }
    }

    private fun renderGames(top: List<G>, online: Boolean) {
        val now = System.currentTimeMillis()
        val hf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dayF = SimpleDateFormat("yyyyMMdd", Locale.US)
        val labF = SimpleDateFormat("EEE dd/MM", Locale("pt", "BR"))
        gamesRow.removeAllViews()
        if (top.isEmpty()) gamesRow.addView(msg(if (online) "Nenhum jogo próximo encontrado" else "Sem resposta da API de jogos ($lastErr). Tente de novo em 1 minuto."))
        for (g in top) {
            val dt = Date(g.ts)
            val dia = when (dayF.format(dt)) {
                dayF.format(Date()) -> "Hoje"
                dayF.format(Date(now + 86_400_000L)) -> "Amanhã"
                else -> labF.format(dt).replaceFirstChar { it.uppercase() }
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
                background = roundBg(0x337C3AED, dp(14).toFloat())
            }
            card.addView(TextView(this).apply { text = "$dia · ${hf.format(dt)}"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ROXO) })
            card.addView(TextView(this).apply { text = g.title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            card.addView(TextView(this).apply { text = g.league; textSize = 12f; setTextColor(0xAAFFFFFF.toInt()) })
            card.addView(TextView(this).apply { text = "📺 " + g.chan; textSize = 12f; setTextColor(0xFFD8C4FF.toInt()); setPadding(0, dp(4), 0, 0) })
            focusScale(card, card.background as GradientDrawable, 1.05f)
            gamesRow.addView(card, LinearLayout.LayoutParams(dp(260), -2).apply { rightMargin = dp(12) })
        }
    }

    private fun loadMedia(path: String, row: LinearLayout) {
        net.execute {
            val arr = try {
                JSONObject(cachedGet(this, "m_$path",
                    "https://api.themoviedb.org/3/trending/$path/week?language=pt-BR&api_key=$TMDB", 30 * 60_000L) ?: "")
                    .optJSONArray("results")
            } catch (e: Exception) { null }
            runOnUiThread {
                row.removeAllViews()
                if (path == "movie") movieArr = arr else seriesArr = arr
                rebuildHero()
                if (arr == null) row.addView(msg("Configure a chave do TMDB ou verifique a internet"))
                else for (i in 0 until minOf(10, arr.length())) {
                    val o = arr.getJSONObject(i)
                    val title = s(o, "title").ifEmpty { s(o, "name") }
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4))
                        background = roundBg(Color.TRANSPARENT, dp(14).toFloat())
                    }
                    val iv = ImageView(this).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = roundBg(0x337C3AED, dp(12).toFloat()); clipToOutline = true
                        outlineProvider = ViewOutlineProvider.BACKGROUND
                    }
                    val poster = s(o, "poster_path")
                    if (poster.isNotEmpty()) Img.load(imgIo, iv, "https://image.tmdb.org/t/p/w185$poster")
                    card.addView(iv, LinearLayout.LayoutParams(dp(120), dp(180)))
                    card.addView(TextView(this).apply {
                        text = "${i + 1}. $title"; setTextColor(Color.WHITE); textSize = 12f; maxLines = 2
                        setPadding(0, dp(4), 0, 0)
                    }, LinearLayout.LayoutParams(dp(120), -2))
                    focusScale(card, card.background as GradientDrawable, 1.06f)
                    row.addView(card, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
                }
            }
        }
    }
}
