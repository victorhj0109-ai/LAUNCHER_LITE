package br.launcher.lite

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    // Chave gratuita em https://www.themoviedb.org/settings/api
    private val TMDB = "COLOQUE_SUA_CHAVE_TMDB"
    private val io = Executors.newFixedThreadPool(3)
    private lateinit var appsRow: LinearLayout
    private lateinit var gamesRow: LinearLayout
    private lateinit var moviesRow: LinearLayout
    private lateinit var seriesRow: LinearLayout
    private var lastLoad = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF050B24.toInt(), 0xFF0B2A6B.toInt())))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(24), dp(32), dp(32))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "Launcher Lite"; textSize = 24f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextClock(this).apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 20f; setTextColor(Color.WHITE) })
        root.addView(head)
        appsRow = section(root, "Seus apps")
        gamesRow = section(root, "Jogos de hoje")
        moviesRow = section(root, "Top 10 filmes da semana")
        seriesRow = section(root, "Top 10 séries da semana")
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshApps()
        if (System.currentTimeMillis() - lastLoad > 15 * 60_000L) {
            lastLoad = System.currentTimeMillis()
            loadGames(); loadMedia("movie", moviesRow); loadMedia("tv", seriesRow)
        }
    }

    private fun section(root: LinearLayout, title: String): LinearLayout {
        root.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(0xFF9FB6FF.toInt()); setPadding(0, dp(20), 0, dp(6))
        })
        val row = LinearLayout(this)
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        return row
    }

    private fun msg(t: String) = TextView(this).apply { text = t; setTextColor(0xAAFFFFFF.toInt()); textSize = 14f }

    private fun refreshApps() {
        appsRow.removeAllViews()
        appsRow.addView(bubble(this, "Explorar", null, "▦", 0xFF1E3FAE.toInt(),
            { startActivity(Intent(this, AllAppsActivity::class.java)) }))
        val pm = packageManager
        for (p in favs(this)) try {
            val ic = pm.getApplicationIcon(p)
            val lb = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            appsRow.addView(bubble(this, lb, ic, null, 0xFF16295F.toInt(), { launchPkg(this, p) },
                { saveFavs(this, favs(this) - p); refreshApps() }))
        } catch (e: Exception) { }
        appsRow.addView(bubble(this, "Adicionar", null, "+", 0x33FFFFFF,
            { startActivity(Intent(this, AllAppsActivity::class.java).putExtra("pick", true)) }))
    }

    private fun s(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k)

    private fun loadGames() {
        io.execute {
            class G(val ts: Long, val title: String, val sub: String)
            val list = ArrayList<G>()
            try {
                val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val base = "https://www.thesportsdb.com/api/v1/json/3/"
                val ev = JSONObject(httpGet(base + "eventsday.php?d=$d&s=Soccer") ?: "{}").optJSONArray("events")
                val tv = JSONObject(httpGet(base + "eventstv.php?d=$d&s=Soccer") ?: "{}").optJSONArray("tvevents")
                val ch = HashMap<String, LinkedHashSet<String>>()
                if (tv != null) for (i in 0 until tv.length()) {
                    val o = tv.getJSONObject(i)
                    if (s(o, "strCountry") == "Brazil") ch.getOrPut(s(o, "idEvent")) { LinkedHashSet() }.add(s(o, "strChannel"))
                }
                val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                val fmtOut = SimpleDateFormat("HH:mm", Locale.getDefault())
                if (ev != null) for (i in 0 until ev.length()) {
                    val o = ev.getJSONObject(i)
                    val lg = s(o, "strLeague"); val id = s(o, "idEvent")
                    val br = lg.contains("Brazil", true) || lg.contains("Brasil", true) ||
                        lg.contains("Libertadores") || lg.contains("Sudamericana") || ch.containsKey(id)
                    if (!br) continue
                    val ts = try { fmtIn.parse(s(o, "strTimestamp"))?.time ?: 0L } catch (e: Exception) { 0L }
                    val hora = if (ts > 0) fmtOut.format(Date(ts)) else s(o, "strTime").take(5)
                    val onde = ch[id]?.joinToString(", ") ?: "consulte a programação"
                    list.add(G(ts, s(o, "strHomeTeam") + " x " + s(o, "strAwayTeam"), "$hora · $lg\nOnde: $onde"))
                }
            } catch (e: Exception) { }
            list.sortBy { it.ts }
            runOnUiThread {
                gamesRow.removeAllViews()
                if (list.isEmpty()) gamesRow.addView(msg("Nenhum jogo encontrado hoje (ou sem internet)"))
                for (g in list) gamesRow.addView(TextView(this).apply {
                    text = g.title + "\n" + g.sub; setTextColor(Color.WHITE); textSize = 14f
                    setPadding(dp(16), dp(12), dp(16), dp(12)); background = roundBg(0x33FFFFFF, dp(14).toFloat())
                    focusScale(this)
                }, LinearLayout.LayoutParams(dp(260), -2).apply { rightMargin = dp(12) })
            }
        }
    }

    private fun loadMedia(path: String, row: LinearLayout) {
        io.execute {
            val arr = try {
                JSONObject(httpGet("https://api.themoviedb.org/3/trending/$path/week?language=pt-BR&api_key=$TMDB") ?: "")
                    .optJSONArray("results")
            } catch (e: Exception) { null }
            runOnUiThread {
                row.removeAllViews()
                if (arr == null) row.addView(msg("Configure a chave do TMDB ou verifique a internet"))
                else for (i in 0 until minOf(10, arr.length())) {
                    val o = arr.getJSONObject(i)
                    val title = s(o, "title").ifEmpty { s(o, "name") }
                    val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(12), 0) }
                    val iv = ImageView(this).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = roundBg(0x33FFFFFF, dp(12).toFloat()); clipToOutline = true
                        outlineProvider = ViewOutlineProvider.BACKGROUND
                    }
                    val poster = s(o, "poster_path")
                    if (poster.isNotEmpty()) Img.load(io, iv, "https://image.tmdb.org/t/p/w185$poster")
                    card.addView(iv, LinearLayout.LayoutParams(dp(120), dp(180)))
                    card.addView(TextView(this).apply {
                        text = "${i + 1}. $title"; setTextColor(Color.WHITE); textSize = 12f; maxLines = 2
                        setPadding(0, dp(4), 0, 0)
                    }, LinearLayout.LayoutParams(dp(120), -2))
                    focusScale(card)
                    row.addView(card)
                }
            }
        }
    }
}
