package br.launcher.lite

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView

class AllAppsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pick = intent.getBooleanExtra("pick", false)
        val pm = packageManager
        val map = LinkedHashMap<String, ResolveInfo>()
        for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0).forEach {
                if (it.activityInfo.packageName != packageName) map.putIfAbsent(it.activityInfo.packageName, it)
            }
        }
        val items = map.values.sortedBy { it.loadLabel(pm).toString().lowercase() }
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF000000.toInt(), 0xFF2A0A4D.toInt())))
        val grid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT; columnWidth = dp(100)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(dp(24), dp(24), dp(24), dp(24)); setBackgroundColor(Color.TRANSPARENT)
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(p: Int) = items[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                    val ri = items[p]; val pkg = ri.activityInfo.packageName
                    return bubble(this@AllAppsActivity, ri.loadLabel(pm).toString(), ri.loadIcon(pm), null,
                        0xFF2B1750.toInt(), {
                            if (pick) {
                                saveFavs(this@AllAppsActivity, (favs(this@AllAppsActivity) + pkg).distinct()); finish()
                            } else launchPkg(this@AllAppsActivity, pkg)
                        })
                }
            }
        }
        setContentView(grid)
    }
}
