package br.launcher.lite

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

class AllAppsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pick = intent.getBooleanExtra("pick", false)
        val pm = packageManager
        val map = LinkedHashMap<String, ResolveInfo>()
        for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0).forEach {
                if (it.activityInfo.packageName != packageName) map.putIfAbsent(it.activityInfo.packageName, it)
            }
        }
        val items = map.values.sortedBy { it.loadLabel(pm).toString().lowercase() }
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF000000.toInt(), 0xFF2A0A4D.toInt())))
        val cols = maxOf(2, (resources.displayMetrics.widthPixels - dp(48)) / dp(148))
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(24), dp(24), dp(24))
            clipChildren = false; clipToPadding = false
        }
        var row: LinearLayout? = null
        items.forEachIndexed { i, ri ->
            if (i % cols == 0) { row = LinearLayout(this).apply { clipChildren = false }; list.addView(row) }
            val pkg = ri.activityInfo.packageName
            row!!.addView(bubble(this, ri.loadLabel(pm).toString(), ri.loadIcon(pm), null, 0xFF2B1750.toInt(), {
                if (pick) { saveFavs(this, (favs(this) + pkg).distinct()); finish() }
                else launchPkg(this, pkg)
            }, null, bannerFor(pm, pkg)), LinearLayout.LayoutParams(dp(148), -2))
        }
        setContentView(ScrollView(this).apply { clipChildren = false; clipToPadding = false; addView(list) })
        (list.getChildAt(0) as? ViewGroup)?.getChildAt(0)?.requestFocus()
    }
}
