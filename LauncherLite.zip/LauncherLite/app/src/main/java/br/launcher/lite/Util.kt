package br.launcher.lite

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

@Volatile var lastErr = ""

fun httpGet(u: String): String? = try {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 8000; c.readTimeout = 8000
    c.setRequestProperty("User-Agent", "Mozilla/5.0 JVLauncher/1.0")
    c.setRequestProperty("Accept", "application/json")
    if (c.responseCode != 200) { lastErr = "HTTP " + c.responseCode; null }
    else c.inputStream.bufferedReader().use { it.readText() }
} catch (e: Exception) { lastErr = e.javaClass.simpleName; null }

object Img {
    private val cache = LruCache<String, Bitmap>(24)
    fun load(io: Executor, v: ImageView, url: String) {
        cache.get(url)?.let { v.setImageBitmap(it); return }
        io.execute {
            try {
                val b = BitmapFactory.decodeStream(URL(url).openStream())
                if (b != null) { cache.put(url, b); v.post { v.setImageBitmap(b) } }
            } catch (e: Exception) { }
        }
    }
}

fun focusScale(v: View, ring: GradientDrawable? = null) {
    v.isFocusable = true
    v.setOnFocusChangeListener { x, f ->
        x.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(120).start()
        ring?.setStroke(if (f) x.context.dp(3) else 0, 0xFFD8B4FE.toInt())
    }
}

fun roundBg(color: Int, radius: Float = -1f) = GradientDrawable().apply {
    if (radius < 0) shape = GradientDrawable.OVAL else cornerRadius = radius
    setColor(color)
}

fun launchPkg(c: Context, pkg: String) {
    val pm = c.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun favs(c: Context): List<String> =
    c.getSharedPreferences("l", 0).getString("f", "")!!.split(",").filter { it.isNotEmpty() }

fun saveFavs(c: Context, l: List<String>) =
    c.getSharedPreferences("l", 0).edit().putString("f", l.joinToString(",")).apply()

fun bubble(c: Context, label: String, icon: Drawable?, glyph: String?, bg: Int,
           click: () -> Unit, onLong: (() -> Unit)? = null): View {
    val s = c.dp(76)
    val col = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(c.dp(4), c.dp(6), c.dp(4), c.dp(6))
    }
    val circle = FrameLayout(c).apply {
        background = roundBg(bg); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
    }
    if (icon != null) {
        circle.addView(ImageView(c).apply {
            setImageDrawable(icon); setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        }, FrameLayout.LayoutParams(s, s))
    } else {
        circle.addView(TextView(c).apply {
            text = glyph; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(s, s))
    }
    val ringBg = roundBg(Color.TRANSPARENT)
    val ring = FrameLayout(c).apply { background = ringBg; setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4)) }
    ring.addView(circle, FrameLayout.LayoutParams(s, s))
    col.addView(ring, LinearLayout.LayoutParams(s + c.dp(8), s + c.dp(8)))
    col.addView(TextView(c).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
        ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setPadding(0, c.dp(4), 0, 0)
    }, LinearLayout.LayoutParams(s + c.dp(16), LinearLayout.LayoutParams.WRAP_CONTENT))
    focusScale(col, ringBg)
    col.setOnClickListener { click() }
    if (onLong != null) col.setOnLongClickListener { onLong(); true }
    return col
}
