package br.launcher.lite

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

@Volatile var lastErr = ""

fun httpGet(u: String): String? = try {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 5000; c.readTimeout = 8000
    c.setRequestProperty("User-Agent", "Mozilla/5.0 JVLauncher/1.0")
    c.setRequestProperty("Accept", "application/json")
    if (c.responseCode != 200) { lastErr = "HTTP " + c.responseCode; null }
    else c.inputStream.bufferedReader().use { it.readText() }
} catch (e: Exception) { lastErr = e.javaClass.simpleName; null }

object Img {
    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(k: String, v: Bitmap) = v.byteCount
    }
    fun load(io: Executor, v: ImageView, url: String) {
        cache.get(url)?.let { v.setImageBitmap(it); return }
        io.execute {
            try {
                val b = BitmapFactory.decodeStream(URL(url).openStream())
                if (b != null) { cache.put(url, b); v.post { v.setImageBitmap(b) } }
            } catch (e: Exception) { }
        }
    }
}

fun focusScale(v: View, ring: GradientDrawable? = null, sc: Float = 1.1f) {
    v.isFocusable = true
    v.setOnFocusChangeListener { x, f ->
        x.animate().scaleX(if (f) sc else 1f).scaleY(if (f) sc else 1f).setDuration(120).start()
        ring?.setStroke(if (f) x.context.dp(3) else 0, 0xFFD8B4FE.toInt())
    }
}

fun roundBg(color: Int, radius: Float = -1f) = GradientDrawable().apply {
    if (radius < 0) shape = GradientDrawable.OVAL else cornerRadius = radius
    setColor(color)
}

fun launchPkg(c: Context, pkg: String) {
    val pm = c.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun favs(c: Context): List<String> =
    c.getSharedPreferences("l", 0).getString("f", "")!!.split(",").filter { it.isNotEmpty() }

fun saveFavs(c: Context, l: List<String>) =
    c.getSharedPreferences("l", 0).edit().putString("f", l.joinToString(",")).apply()

fun bannerFor(pm: PackageManager, pkg: String): Drawable? = try {
    val i = pm.getLeanbackLaunchIntentForPackage(pkg)
    val ai = if (i != null) pm.resolveActivity(i, 0)?.activityInfo else null
    ai?.loadBanner(pm) ?: pm.getApplicationBanner(pkg)
} catch (e: Exception) { null }

fun iconBg(d: Drawable, def: Int): Int = try {
    val b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
    val old = Rect(d.bounds)
    d.setBounds(0, 0, 16, 16); d.draw(Canvas(b)); d.bounds = old
    val p = b.getPixel(1, 8)
    if ((p ushr 24) >= 250) p else def
} catch (e: Exception) { def }

fun iconStyle(c: Context): String = c.getSharedPreferences("l", 0).getString("style", "round") ?: "round"

fun launchableApps(c: Context): List<ResolveInfo> {
    val pm = c.packageManager
    val map = LinkedHashMap<String, ResolveInfo>()
    for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0).forEach {
            if (it.activityInfo.packageName != c.packageName) map.putIfAbsent(it.activityInfo.packageName, it)
        }
    }
    return map.values.sortedBy { it.loadLabel(pm).toString().lowercase() }
}

fun bubble(c: Context, label: String, icon: Drawable?, glyph: String?, bg: Int,
           click: () -> Unit, onLong: (() -> Unit)? = null, banner: Drawable? = null): View {
    val rect = iconStyle(c) == "rect"
    val useBanner = rect && banner != null
    val s = c.dp(76)
    val w = if (useBanner) c.dp(135) else s
    val rad = if (useBanner) c.dp(14).toFloat() else c.dp(18).toFloat()
    val col = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(c.dp(4), c.dp(6), c.dp(4), c.dp(6))
    }
    val base = if (icon != null) iconBg(icon, bg) else bg
    val shape = when {
        useBanner -> roundBg(0xFF000000.toInt(), rad)
        rect -> roundBg(base, rad)
        else -> roundBg(base)
    }
    val circle = FrameLayout(c).apply {
        background = shape; clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
    }
    if (useBanner) {
        circle.addView(ImageView(c).apply { setImageDrawable(banner); scaleType = ImageView.ScaleType.CENTER_CROP },
            FrameLayout.LayoutParams(w, s))
    } else if (icon != null) {
        circle.addView(ImageView(c).apply { setImageDrawable(icon); scaleType = ImageView.ScaleType.CENTER_CROP },
            FrameLayout.LayoutParams(s, s))
    } else {
        circle.addView(TextView(c).apply {
            text = glyph; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(s, s))
    }
    val ringBg = if (rect) roundBg(Color.TRANSPARENT, rad + c.dp(4)) else roundBg(Color.TRANSPARENT)
    val ring = FrameLayout(c).apply { background = ringBg; setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4)) }
    ring.addView(circle, FrameLayout.LayoutParams(w, s))
    col.addView(ring, LinearLayout.LayoutParams(w + c.dp(8), s + c.dp(8)))
    col.addView(TextView(c).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
        ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setPadding(0, c.dp(4), 0, 0)
    }, LinearLayout.LayoutParams(w + c.dp(16), LinearLayout.LayoutParams.WRAP_CONTENT))
    focusScale(col, ringBg)
    col.setOnClickListener { click() }
    if (onLong != null) col.setOnLongClickListener { onLong(); true }
    return col
}

fun cachedGet(c: Context, key: String, url: String, ttl: Long): String? {
    val sp = c.getSharedPreferences("cache", 0)
    val t = sp.getLong("t_$key", 0)
    val old = sp.getString("v_$key", null)
    if (old != null && System.currentTimeMillis() - t < ttl) return old
    val r = httpGet(url)
    if (r != null) {
        sp.edit().putString("v_$key", r).putLong("t_$key", System.currentTimeMillis()).apply()
        return r
    }
    return old
}
