package br.launcher.lite

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun httpGet(u: String): String? = try {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 8000; c.readTimeout = 8000
    c.inputStream.bufferedReader().use { it.readText() }
} catch (e: Exception) { null }

object Img {
    private val cache = LruCache<String, Bitmap>(24)
    fun load(io: Executor, v: ImageView, url: String) {
        cache.get(url)?.let { v.setImageBitmap(it); return }
        io.execute {
            try {
                val b = BitmapFactory.decodeStream(URL(url).openStream())
                if (b != null) { cache.put(url, b); v.post { v.setImageBitmap(b) } }
            } catch (e: Exception) { }
        }
    }
}

fun focusScale(v: View) {
    v.isFocusable = true
    v.setOnFocusChangeListener { x, f ->
        x.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(120).start()
    }
}

fun roundBg(color: Int, radius: Float = -1f) = GradientDrawable().apply {
    if (radius < 0) shape = GradientDrawable.OVAL else cornerRadius = radius
    setColor(color)
}

fun launchPkg(c: Context, pkg: String) {
    val pm = c.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun favs(c: Context): List<String> =
    c.getSharedPreferences("l", 0).getString("f", "")!!.split(",").filter { it.isNotEmpty() }

fun saveFavs(c: Context, l: List<String>) =
    c.getSharedPreferences("l", 0).edit().putString("f", l.joinToString(",")).apply()

fun bubble(c: Context, label: String, icon: Drawable?, glyph: String?, bg: Int,
           click: () -> Unit, onLong: (() -> Unit)? = null): View {
    val s = c.dp(76)
    val col = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(c.dp(8), c.dp(8), c.dp(8), c.dp(8))
    }
    val circle = FrameLayout(c).apply {
        background = roundBg(bg); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
    }
    if (icon != null) {
        circle.addView(ImageView(c).apply {
            setImageDrawable(icon); setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        }, FrameLayout.LayoutParams(s, s))
    } else {
        circle.addView(TextView(c).apply {
            text = glyph; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(s, s))
    }
    col.addView(circle, LinearLayout.LayoutParams(s, s))
    col.addView(TextView(c).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
        ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setPadding(0, c.dp(6), 0, 0)
    }, LinearLayout.LayoutParams(s + c.dp(12), LinearLayout.LayoutParams.WRAP_CONTENT))
    focusScale(col)
    col.setOnClickListener { click() }
    if (onLong != null) col.setOnLongClickListener { onLong(); true }
    return col
}
